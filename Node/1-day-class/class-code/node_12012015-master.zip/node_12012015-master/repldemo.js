var t = 23;
t
console.log(t);
var o = { id: 2 };
o
o.id
o["id"]
o.address = { street: "123 Main St.", zipcode: "94043" }
o
var colors = [];
colors
colors.push("red");
colors
colors.unshift("purple");
colors
colors.message = "Intuit Rocks!";
colors
o[30] = "test";
o
o['id']
function square(x) { return x * x; }
square(4);
square.prop = "Test";
square
square(4, 5);
1/0
Infinity + Infinity
Infinity * Infinity
Infinity / Infinity
1 == "1"
1 === "1"
function cube(y) {
return y * y * y;
}
cube(5);
