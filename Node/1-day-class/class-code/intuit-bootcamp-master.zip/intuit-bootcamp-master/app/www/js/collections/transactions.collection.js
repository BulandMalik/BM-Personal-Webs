var Transactions = BaseCollection.extend({
	model: Transaction,
	url: "/api/transactions"
});
