define({
  "greeting": "Don't miss the bus!"
});
