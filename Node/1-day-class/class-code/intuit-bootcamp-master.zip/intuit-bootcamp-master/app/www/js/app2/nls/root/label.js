define({
  "greeting": "Hello!"
});
