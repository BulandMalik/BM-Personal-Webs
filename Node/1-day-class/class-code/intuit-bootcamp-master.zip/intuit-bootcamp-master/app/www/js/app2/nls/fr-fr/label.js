define({
  "greeting": "Bonjour!"
});
