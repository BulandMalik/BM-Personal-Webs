
window.addEventListener("DOMContentLoaded", function() {
	document.open("text/html", "replace");
	document.writeln("Some text!");
	document.close();
});
