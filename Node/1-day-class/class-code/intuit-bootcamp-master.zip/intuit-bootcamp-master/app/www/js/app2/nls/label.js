define({
	root: true,
	"fr-fr": true,
	"suma-suma": true
});
