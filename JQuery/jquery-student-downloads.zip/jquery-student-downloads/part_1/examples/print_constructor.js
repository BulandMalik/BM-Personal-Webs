var loc = new Object();
loc.latitude = 37.0625;
loc.longitude = -96.677068;

print(loc.constructor);