// multiple statements per line
print("Packed in a single line"); print("Use only for readability");