// do while loop
var total = 0, count = 1;
do {
  total += count;
  count += 1;
} while (count <= 10)
print(total);