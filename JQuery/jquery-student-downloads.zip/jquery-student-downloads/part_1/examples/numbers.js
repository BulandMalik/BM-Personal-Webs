// numbers
print(2 + 3 * 3);
print(1 / 0);
print(Math.sqrt(-1));