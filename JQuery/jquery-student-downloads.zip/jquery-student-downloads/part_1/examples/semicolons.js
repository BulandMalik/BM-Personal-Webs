// semicolons are 'sometimes' optional
print("There is no semicolon")