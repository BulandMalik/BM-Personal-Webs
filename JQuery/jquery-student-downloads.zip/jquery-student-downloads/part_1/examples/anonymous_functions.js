(function() {
	print("I've been to the desert on horse with no name");
})();