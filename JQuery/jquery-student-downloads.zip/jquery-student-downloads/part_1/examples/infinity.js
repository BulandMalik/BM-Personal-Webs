var value = 2;
for (var i = 1; value < Infinity; i++) {
  value = Math.pow(value, 2);
  print("i ==> " + value);
}