var an_object = {
	a_method: function() {
		print(this);
	}
}
an_object.a_method();