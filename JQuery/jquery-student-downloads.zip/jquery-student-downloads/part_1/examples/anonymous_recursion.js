var f = function(x) { 
	return (x < 1) ? 0 : x + arguments.callee(x - 1);
};
print(f(10));