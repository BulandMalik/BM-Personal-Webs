function foo() {
	1 + 2;
}

print(foo());