// while loop
var total = 0, count = 1;
while (count <= 10) {
  total += count;
  count += 1;
}
print(total);