// equality
print(2 + 3 * 3 == '11');  // regular equality
print(2 + 3 * 3 === '11'); // strict equality