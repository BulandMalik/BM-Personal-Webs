// define the plugin
(function($){
	$.fn.extend({ 

	});
})(jQuery);