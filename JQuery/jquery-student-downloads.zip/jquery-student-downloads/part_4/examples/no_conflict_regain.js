jQuery.noConflict(); 

(function($) {
	$(function() { 
		// this now works work
		$("p").show();
	}); 
})(jQuery);