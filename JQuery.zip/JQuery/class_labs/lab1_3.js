

var num: [1,2,3];

Array.prototype.each : function(func){

		func.call(this[i]);
}

num.each(fucntion(){retunr this;})

