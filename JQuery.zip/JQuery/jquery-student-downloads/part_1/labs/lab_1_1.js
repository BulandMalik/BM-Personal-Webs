function fib(n) {
}

print(fib(20));