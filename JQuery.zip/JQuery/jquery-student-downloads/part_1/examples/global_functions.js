print("Calling a function before it is 'defined' ==> " 
      + sayHello("My Little Friend"));
function sayHello(to) {
	return "Say Hello to " + to;
}