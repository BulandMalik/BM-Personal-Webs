var decimal = 1972;
var to_hex = decimal.toString(16);
var to_binary = decimal.toString(2);
var to_septenary = decimal.toString(7);
var to_quaternary = decimal.toString(4);

print(decimal);
print(to_hex);
print(to_binary);
print(to_septenary);
print(to_quaternary);