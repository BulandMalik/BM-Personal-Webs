print(1/0);
print(-1/0);
print(Infinity/Infinity);
print(Infinity - Infinity);
print(Infinity / 0);
print(-Infinity / 0);