// strings
print('This is a String');
print("This is also a String");