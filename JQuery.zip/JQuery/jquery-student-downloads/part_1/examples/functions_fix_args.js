function add_two_things(thing_one, thing_two) {
	return thing_one + thing_two;
}

print(add_two_things(1, 3));
print(add_two_things("Double ", "Rainbow"));
print(add_two_things(8, 6, 7, 5, 3, 0, 9));