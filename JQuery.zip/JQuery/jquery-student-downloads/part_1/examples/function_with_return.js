function foo() {
	return "bar";
}

print(foo());