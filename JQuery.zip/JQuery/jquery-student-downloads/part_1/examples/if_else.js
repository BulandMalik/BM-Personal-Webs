// if-else
if (2 + 3 * 5 === 17) {
	print("Yup, it is true!");
}
else {
	print("Nope, that was a lie!");
}