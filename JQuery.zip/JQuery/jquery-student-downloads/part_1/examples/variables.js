// declaration
var book_title; 
print(book_title);

// assignment
book_title = "JavaScript: The Good Parts"; 
print(book_title);

// explicit declaration & assignment
var one_more_book_title = "JavaScript: The Definitive Guide"; 

// implicit declaration & assignment
yet_another_book_title = "Secrets of the JavaScript Ninja";   
print(one_more_book_title + ' and ' + yet_another_book_title);

var num;
print("num:"+num);