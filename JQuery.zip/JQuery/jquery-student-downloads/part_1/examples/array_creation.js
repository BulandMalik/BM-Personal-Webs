var array_one = [];
var array_two = new Array(7);
var array_three = [7];
var array_four = Array(7);

print(array_one);
print(array_two);
print(array_three);
print(array_four);

array_one[4] = 'than'
array_one[1] = 'done'
array_one[6] = 'said'
array_one[3] = 'better'
array_one[0] = 'well'
array_one[2] = 'is'
array_one[5] = array_one[0]

array_two[11] = 8675309;

print(array_one);
print(array_two);
print(array_two[12]);
