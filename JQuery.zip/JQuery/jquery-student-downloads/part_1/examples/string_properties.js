var address = {
	"street-one" : "10544 East Meadowhill Dr.",
	city : "Scottsdale",
	state : "AZ",
	zip : 85255
};

print(address["street-one"] + ", " + 
      address.city + " " + 
      address.state + " " + 
      address.zip);