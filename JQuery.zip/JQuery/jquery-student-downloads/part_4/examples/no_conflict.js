// give $ back
jQuery.noConflict();

// use jQuery 
jQuery("p").hide();

// this wouldn't work
$("p").show();
