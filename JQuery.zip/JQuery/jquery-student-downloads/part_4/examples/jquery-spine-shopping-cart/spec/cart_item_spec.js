describe("CartItem", function() {
	var cartItem;

	beforeEach(function() {
	});

	describe("a new cart", function() {
	});
});